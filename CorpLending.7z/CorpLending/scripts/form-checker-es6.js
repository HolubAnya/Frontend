﻿class FormChecker{
	constructor(sSelector){
		// свойства
		this.elem = $(sSelector);
		
		this.textfields		= this.elem.find(".b-textfield"); // текстовые поля
		this.errorMessage	= this.elem.find(".b-form__message_error"); // див с сообщением об ошибке
		this.error          = this.elem.find(".b-form__message");
		this.createEvents();
	}
	
	// методы
	checkTextfield(event, textfield = {}){
		let currentTextfield 		= textfield.length ? textfield : $(event.currentTarget)
			,currentTextfieldVal 	= currentTextfield.val()
			,regexps				= {
					 "name" 		: "^[A-Za-zА-Яа-я ]{3,15}$" // лат, рус буквы, пробел - 3 15
					,"email" 		: "^[a-z0-9_\\-]{1,15}@[a-z]{1,8}\\.([a-z]{1,2}){1,2}" // лат буквы, -, _ - 1 15
					,"password" 	: "^[0-9A-Za-z]{6,12}$" // целое число 2 6
				}
			,currentTextfieldName 	= currentTextfield.attr("name")
			,currentRegexp			= new RegExp(regexps[currentTextfieldName])
			,isTextfieldError		= ! currentTextfieldVal.match(currentRegexp)
			;
		currentTextfield.toggleClass("b-textfield_error", isTextfieldError);
		return isTextfieldError;
	}
	checkTextfieldsGroup(event){
		event.preventDefault(); // предотвращает событие по умолчанию
		let isFormError = false;
 			this.textfields.each((i, textfield)=>{
				let currentTextfield 	= $(textfield)
					,isTextfieldError 	= this.checkTextfield(null, currentTextfield);
					
					if(isTextfieldError){
						isFormError = true;
					}
				});
				// if (isFormError){
				// 	this.error.css("display", "block");
				// }
		isFormError ? this.errorMessage.stop().slideDown() : this.errorMessage.stop().slideUp();
	}
	
	createEvents(){
		// события
		this.textfields.blur(this.checkTextfield.bind(this)); // при потере фокуса blur полем - метод проверки одного поля
		this.elem.submit(this.checkTextfieldsGroup.bind(this)); // при отправке данных на сервер - метод проверки всех полей формы
	}
}