function Slider(sSelector){
    let g                 = this;

    g.slider             = $(sSelector);
    g.arrowPrev           = g.slider.find(".b-preview__arrow_prev");
    g.arrowNext           = g.slider.find(".b-preview__arrow_next");
    g.image1              = g.slider.find(".image1");
    g.image2              = g.slider.find(".image2");
    
    g.currentPictureIndex = 0;
    g.max                 = 7;



    g.showPrevious = function(){
        g.showImage(-2);
    }
    g.showNext = function(){
        g.showImage(2);
    }

    g.showImage = function(iStep){
        let path = "images/";
        g.currentPictureIndex += iStep;
        if (g.currentPictureIndex >= g.max){
            g.currentPictureIndex = 0;
        }
        else if (g.currentPictureIndex < 0){
            g.currentPictureIndex = g.max - 2;
        }
        g.image1.attr("src", path + g.currentPictureIndex  + ".jpg");
        g.image2.attr("src", path + (g.currentPictureIndex + 1)  + ".jpg");
        console.log(g.currentPictureIndex);
    }

























    // g.showImage = function(iStep){
    //     let jqPictureleft = g.previewImage1.attr("src");
    //     g.currentPictureIndex = g.pictures.index(jqPictureleft);
    //     //g.currentPictureIndex += iStep;
    //     if (g.currentPictureIndex >= g.max){
    //         g.currentPictureIndex = 0;
    //     }
    //     else if (g.currentPictureIndex < 0){
    //         g.currentPictureIndex = g.max - 1;
    //     }
    //     //let jqPicture  = g.pictures.eq(g.currentPictureIndex).children(".b-picture__image").attr("src", g.currentPictureIndex);
    //     let left = g.currentPictureIndex+iStep;
    //     let center = g.currentPictureIndex+iStep+1;
    //     let right = g.currentPictureIndex+iStep+2;
    //     g.previewImage1.attr("src", "images/" + left + ".jpg");
    //     g.previewImage2.attr("src", "images/" + center + ".jpg");
    //     g.previewImage3.attr("src", "images/" + right + ".jpg");
    //     console.log(g.previewImage3.attr("src"));
    // }



    g.arrowPrev.click(g.showPrevious);
    g.arrowNext.click(g.showNext);

}