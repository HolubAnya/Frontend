let colors = ["yellow", "blue", "black", "pink", "orange"];
console.log(colors);


//deleting 
console.log("deleted element", colors.shift());
console.log(colors);

console.log("deleted element", colors.pop());
console.log(colors);

//adding on the 2 position
colors.splice(2, 0, "red");
console.log(colors);

//deleting  on the 1 position
colors.splice(1, 1);
console.log(colors);

//deleting  on the 1 position and adding "white" on this position
colors.splice(1, 1, "white");
console.log(colors);

// colors[10] = "violet";
// console.log(colors);
// console.log(colors.length);

console.log(colors.join(","));
console.log(colors);

