let pets = {
    "001" : {
        "name" : "Bob"
        ,"type" : "cat"
        ,"color" : "grey"
        ,"age" : 10
    }
    ,"002" : {
        "name" : "Klopa"
        ,"type" : "cat"
        ,"color" : "black"
        ,"age" : 2
    }
    ,"003" : {
        "name" : "Amily"
        ,"type" : "cat"
        ,"color" : "white"
        ,"age" : 15
    }
};
 function print(id){
     if (pets[id]["age"] > 5)
        console.log(pets[id]["name"], pets[id]["type"], pets[id]["color"], pets[id]["age"]);
 }

 print("001");
 print("002");
 print("003");