function Gallery(sSelector){
    let g                 = this;

    g.gallery             = $(sSelector);
    g.pictures            = g.gallery.find(".b-picture");
    g.arrowPrev           = g.gallery.find(".b-preview__arrow_prev");
    g.arrowNext           = g.gallery.find(".b-preview__arrow_next");
    g.preview             = g.gallery.find(".b-preview");
    g.previewImage        = g.gallery.find(".b-preview__image");
    g.previewText         = g.gallery.find(".b-preview__text");
    g.currentPictureIndex = 0;
    g.max                 = g.pictures.length;
    g.currentPlace        = g.gallery.find(".b-preview__currentPlace");
    g.maxPlace            = g.gallery.find(".b-preview__maxPlace");

    g.showPreview = function(){
        let jqPicture = $(this);
        console.log(this);
        g.currentPictureIndex = g.pictures.index(jqPicture);
        g.showImage(0);
        g.preview.addClass("b-preview_shown");
    }
    g.hidePreview = function(event){
        if(!event || $(event.target).hasClass("b-preview")){
            g.preview.removeClass("b-preview_shown");
        }
    }
    g.showPrevious = function(){
        g.showImage(-1);
    }
    g.showNext = function(){
        g.showImage(1);
    }
    g.showImage = function(iStep){
        g.currentPictureIndex += iStep;
        if (g.currentPictureIndex >= g.max){
            g.currentPictureIndex = 0;
        }
        else if (g.currentPictureIndex < 0){
            g.currentPictureIndex = g.max - 1;
        }
        let jqPicture  = g.pictures.eq(g.currentPictureIndex).children(".b-picture__image").attr("src").replace("small_", "");
        g.previewImage.attr("src", jqPicture);
        g.currentPlace.text(g.currentPictureIndex + 1);
        g.maxPlace.text(g.max);
        g.previewText.text(g.pictures.eq(g.currentPictureIndex).children(".b-picture__image").attr("alt"));
    }
    g.escHidePreview = function(event){
        if(event.which == 27){
            g.hidePreview();
        }  
    }

    g.pictures.click(g.showPreview);
    g.arrowPrev.click(g.showPrevious);
    g.arrowNext.click(g.showNext);
    g.preview.click(g.hidePreview);
    $("body").keyup(g.escHidePreview);
}