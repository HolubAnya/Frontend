"use strict";

let length    = 10
    ,password = ""
    ;

function getRandom(min, max){
    return Math.random() * (max - min) + min;
}

function getFromChar(first, last){
    password += String.fromCharCode(Math.round(getRandom(first, last)));
    return password;
}
function generate(){
    for (let i = 0; i < length; i++){
        if (i%3){
            getFromChar(97, 122);
            getFromChar(65, 90);
            i++;
        }else 
            getFromChar(48, 57);
    }
    return password;
}

console.log(generate());

