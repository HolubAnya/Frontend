console.log($(".login1").val("editor")); //set value
console.log($(".login1").val()); //console.log value

console.log($(".text").html()); //with tags
console.log($(".text").text()); //without tags

$(".text1").html("text1"); //writing 

console.log($(".login").attr("type")); //read the value of atribute
$(".login1").attr("type", "password"); //change the value of attribute
console.log($(".login1").attr("type"));

$(".text").css("border", "1px solid red");