function caloriesCalculator(){
    let resultPlace = $("#result")
    ,firstDishes    = $("#firstDishes").val()
    ,secondDishes   = $("#secondDishes").val()
    ,drinks         = $("#drinks").val()
    ,weightSecond   = $("#weightSecond").val()
    ,weightFirst    = $("#weightFirst").val()
    ,weightDrink    = $("#weightDrink").val()
    ,table          = {
        "Mushroom soup" : 130
        ,"Fish soup" : 200
        ,"Borsch" : 250
        ,"Pasta" : 150
        ,"MashedPotatoes" : 150
        ,"Tea" : 15
        ,"Juice" : 20
    }
    ,calculate      =  (callory, weight) => {return table[callory] / 100 * parseInt(weight)}
    ,result         =  0;
    ;
    resultPlace.css("display", "block");
    
    (weightFirst != "") ? result += calculate(firstDishes, weightFirst) : result;
    (weightSecond != "") ? result += calculate(secondDishes, weightSecond) : result;
    (weightDrink != "")  ? result += calculate(drinks, weightDrink) : result;

    resultPlace.text(result.toString());
}

$("#btn").click(caloriesCalculator);