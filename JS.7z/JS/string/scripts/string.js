let latters = "AZ"
    ,firstLatterNum = latters.charCodeAt(0)
    ,lastLatterNum  = latters.charCodeAt(1)
    ,list           = ""
    ,sToday         = "26/11/2018"
    ,aToday         = sToday.split("/")
    ,months         = ["j", "f", "m", "a", "may", "june", "july", "august", "sep", "o", "n", "dec", ]
    ;
//console.log(latters.charCodeAt(0), latters.charCodeAt(1));

for(let i = firstLatterNum; i <= lastLatterNum; i++ ){
    list += "<br><a href=\"#" + String.fromCharCode(i) +"\">" + String.fromCharCode(i) + "<\a>\n"; 
}



console.log(aToday[0], months[aToday[1] - 1], aToday[2]);

console.log(sToday.substr(0, 2));
console.log(sToday.slice(3, 7));

var  carPlate = "AA 1234 BB"
    ,plateNumber = carPlate.substr(carPlate.indexOf(" ") + 1, 4);

console.log(plateNumber);

let message   = "Иванов"
    ,symbols  = {"И" : "I",  "в" : "v", "а" : "a"}
    ,translit = " "
    ;

    for (i = 0; i< message.length; i++)
        translit += symbols[message[i]]  ? symbols[message[i]] : message[i];
console.log(message, translit);

let m, n;
Math.floor(Math.random() * (n - m + 1)) + m;
