
	


function Generate(){
    let m          = this;
    m.menu =  {
        "Телефони":
        [
            "Дві SIM-картки"
            ,"З акумулятором великої ємності"
            ,"Доступні смартфони"
            ,"Мобільні телефони"
            ,"Захищені"
        ]
        ,"Телевізори та аксесуари":
        [
            "Телевізори"
            ,"Кабелі та перехідники"
            ,"Кріплення для телевізорів"
            ,"Тумби під телевізор"
            ,"ТВ-антени та ресивери"
            ,"Аксесуари до ТВ"
            ,"Універсальні пульти ДК"
        ]
        ,"Автоелектроніка":
        [
            "Відеореєстратори"
            ,"GPS-навігатори"
            ,"Автосигналізації"
            ,"Автозвук"
            ,"Автосигналізації"
            ,"Паркувальні системи"	
        ]					
    }
    m.str = "";
    // $.each(menu, function(menu, submenu){
// 	str = str + "<ul>" + "<li><a href=''>" + menu + "<ul>";
// 	$.each(submenu, function(i, l){
// 		str = str + "<li><a href=''>" + l + "</li>";
// 	});
// 	str = str + "</ul>" + "</li>" + "</ul>" ;
// });
    m.generate = function(menu){

    }
}
$("body").html(str)
console.log(str);

//              [\w\\-]{5,15}
//              [А-ЯЄЇ]{2}[\d]{6}
//              (\d{2}\\-){2}[\\-\d]{4}
//              (\d{1,3}\\.){3}\d{1,3}
//              [1-9]{1,5}\\.([1-9]{1,2})?
//               0[1-9]|[1-2][0-9]|[3][0-1]{2}
//               [1-9]{1,3}([a-zA-z])?(\\/[1-9]{1,3})?(\\-[1-9]{1,3})?
//               \\.[a-z0-9]{1,6}
//               [w]{3}[\\.a-z]{1,22}[\\.a-z]{2-3}([\\.a-z]{2-3})?
//               (ISBN\s)[0-9]{1,3}\\-[0-9]{2,7}\\-[0-9]{6}\\-[0-9]


function multilevelMenu(parentId, ctgLists, ctgData) {
  var html = '';       // stores and returns the html code with Menu lists

  // if parent item with child IDs in ctgLists
  if(ctgLists[parentId]) {
    html = '<ul>';      // open UL

    // traverses the array with child IDs of current parent, and adds them in LI tags, with their data from ctgData
    for (childId in ctgLists[parentId]) {
      // define CSS class in anchors, useful to be used in CSS style to design the menu
      if(parentId == 0) var clsa = ' class="firsrli"';       // to add class to anchors in main /first categories
      else if(ctgLists[ctgLists[parentId][childId]]) var clsa = ' class="litems"';       // to add class to anchors in lists with childs
      else var clsa = '';

      // open LI
      html += '<li><a href="'+ ctgData[ctgLists[parentId][childId]].lurl +'" title="'+ ctgData[ctgLists[parentId][childId]].lname +'"'+ clsa +'>'+ ctgData[ctgLists[parentId][childId]].lname +'</a>';

      html += multilevelMenu(ctgLists[parentId][childId], ctgLists, ctgData);     // re-calls the function to find parent with child-items recursively

      html += '</li>';      // close LI
    }
    html += '</ul>';       // close UL
  }

  return html;
}