function Game(sSelector){
    let g               = this;
    g.game              = $(sSelector);
    g.userAnswer        = g.game.find(".userAnswer");
    g.computerAnswer    = "";
    g.result            = g.game.find(".result");
    g.userAnswerImg     = g.game.find(".userAnswerImg");
    g.computerAnswerImg = g.game.find(".computerAnswerImg");
    g.messagePlace      = g.game.find(".message");
    g.btn               = g.game.find(".btn");

    g.setComputerAnswer = function(){
        let  m          = 0
            ,n          = 2
            ,randIndex  = Math.floor(Math.random() * (n - m + 1)) + m
            ,answers    = ["rock", "scissors", "paper"]
        g.computerAnswer= answers[randIndex];
    }

    g.play              = function(){
        g.setComputerAnswer();
        console.log(g.computerAnswer);
        let table       = {
            "rock"      : {
                "rock"      : 0
                ,"scissors" : 1
                ,"paper"    : -1
            }
            ,"scissors" : {
                "rock"      : -1
                ,"scissors" : 0
                ,"paper"    : 1
            }
            ,"paper"    : {
                "rock"      : -1
                ,"scissors" : 1
                ,"paper"    : 0
            }
        }
        ,message        = {
            "-1" : ":("
            ,"0" : ":/"
            ,"1" : ":)"
        }
        ;
    g.result.css("display", "block");
    g.userAnswerImg.attr("src", "images/" + g.userAnswer.val() + ".png");
    g.computerAnswerImg.attr("src", "images/" + g.computerAnswer + ".png");
    g.messagePlace.text(message[table[g.userAnswer.val()][g.computerAnswer]]);
    }

    g.btn.click(g.play);
}






// function game(){
//     let  m                 = 0
//         ,n                 = 2
//         ,randIndex         = Math.floor(Math.random() * (n - m + 1)) + m
//         ,answers           = ["rock", "scissors", "paper"]
//         ,computerAnswer    = answers[randIndex]
//         ,userAnswerImg     = document.getElementById("userAnswerImg")
//         ,computerAnswerImg = document.getElementById("computerAnswerImg")
//         ,userAnswer        = document.getElementById("userAnswer")
//         ,messagePlace      = document.getElementById("message")
//         ,table             = {
//             "rock" : {
//                 "rock" : 0
//                 ,"scissors" : 1
//                 ,"paper" : -1
//             }
//             ,"scissors" : {
//                 "rock" : -1
//                 ,"scissors" : 0
//                 ,"paper" : 1
//             }
//             ,"paper" : {
//                 "rock" : -1
//                 ,"scissors" : 1
//                 ,"paper" : 0
//             }
//         }
//         ,message           = {
//             "-1" : ":("
//             ,"0" : ":/"
//             ,"1" : ":)"
//         }
//         ;
//     console.log(userAnswer.value);
//     result.style.display   = "block";
//     userAnswerImg.src      = "images/" + userAnswer.value + ".png";
//     computerAnswerImg.src  = "images/" + computerAnswer + ".png";
//     messagePlace.innerText = message[table[userAnswer.value][computerAnswer]];
// }


// let btn = document.getElementById("btn");
// btn.onclick = game;
