let inputs = document.getElementsByTagName("input");
//console.log(inputs);
//console.log(inputs[0]);
//console.log(inputs[0].type, inputs[0].tagName);

function calculator(){
    let num1      = document.getElementById("num1")
        ,num2     = document.getElementById("num2")
        ,operator = document.getElementById("operators")
        ,result   = document.getElementById("result")
        ;
        //console.log(num1.value, num2.value, operator.value);
        num2.style.boxShadow = "none";
        if (operator.value  == "+")
            result.value = parseInt(num1.value) + parseInt(num2.value);
        if (operator.value  == "-")
            result.value = parseInt(num1.value) - parseInt(num2.value);
        if (operator.value  == "*")
            result.value = parseInt(num1.value) * parseInt(num2.value);
        if (operator.value  == "/"){
            if(parseInt(num2.value)){
                result.value = parseInt(num1.value) / parseInt(num2.value);
            }else {
                result.value = "";
                num2.style.boxShadow = "0 0 4px #ff0000";
            }
        }
        if (operator.value  == "%")
            result.value = parseInt(num1.value) % parseInt(num2.value);
        if (operator.value  == "^")
            result.value = Math.pow(parseInt(num1.value), parseInt(num2.value));
}

let btn = document.getElementById("calc_btn");
btn.onclick = calculator;

