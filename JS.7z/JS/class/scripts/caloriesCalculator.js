function caloriesCalculator(){
    let resultPlace = document.getElementById("result")
    ,firstDishes    = document.getElementById("firstDishes")
    ,secondDishes   = document.getElementById("secondDishes")
    ,drinks         = document.getElementById("drinks")
    ,weightSecond   = document.getElementById("weightSecond")
    ,weightFirst    = document.getElementById("weightFirst")
    ,weightDrink    = document.getElementById("weightDrink")
    ,table          = {
        "Mushroom soup" : 130
        ,"Fish soup" : 200
        ,"Borsch" : 250
        ,"Pasta" : 150
        ,"MashedPotatoes" : 150
        ,"Tea" : 15
        ,"Juice" : 20
    }
    //,result         =  (callory, weight) => {table[callory.value] / 100 * weight.value};
    ;
    resultPlace.style.display   = "block";
    resultPlace.innerText = table[firstDishes.value] / 100 * weightFirst.value + table[drinks.value] / 100 * weightDrink.value + table[secondDishes.value] / 100 * weightSecond.value;
}

let btn = document.getElementById("btn");
btn.onclick = caloriesCalculator;