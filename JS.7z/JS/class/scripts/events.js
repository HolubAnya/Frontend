function showMessage(){
    btn1.innerText = "Your message";
    //btn1.style.backgroundColor = "yellow";
    btn1.className = "btn";
}

let btn1 = document.getElementById("btn1"); //объект кнопка
console.log(btn1);
console.log(btn1.id, btn1.innerText, btn1.tagName);
btn1.onclick = showMessage; //назначаем функцию на событие клик по кнопке
