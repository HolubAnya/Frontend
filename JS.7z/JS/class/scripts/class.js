
class Goods {
    constructor(price, qty, info){
        this.price = price;
        this.qty = qty;
        this.info = info;
    }
    SetQTY(qty){
        this.qty = qty;
        return this.qty;
    }
    SetInfo(info){
        this.info = info;
        return this.info;
    }
    SetPrice(price){
        this.price = price;
        return this.price;
    }
    GetPrice() {
        return this.price;
    }
    GetQTY() {
        return this.qty;
    }
    GetInfo() {
        return this.info;
    }
    View() {
        return `${this.info}, ${this.price}, ${this.qty}`;
    }
    Delete() {
        console.log("Item was deleted");
    }
}

class Phone extends Goods {
    constructor(price, qty, info, diagonal){
        super(price, qty, info);
        this.diagonal = diagonal;
    }
    SetDiagonal(diagonal){
        this.diagonal = diagonal;
        return this.diagonal;
    }
    GetDiagonal() {
        return this.diagonal;
    }
}

const table = new Goods(400, 20, "Wooden table");
const iPhone = new Phone(1300, 20, "X", 5.5);

console.log(table.View());
console.log(table.GetInfo());
console.log(table.SetPrice(300));
console.log(table.GetPrice());
console.log(iPhone.GetPrice());
console.log(iPhone.GetInfo());
console.log(iPhone.GetDiagonal());
