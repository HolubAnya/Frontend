function MoreLess(sSelector){
    let f = this;
    f.container = $(sSelector);
    f.more = f.container.find(".more");
    f.less = f.container.find(".less");
    f.textBox = f.container.find(".tb");
    f.current = f.textBox.val();

    f.showNum = function(){
        if ($(this).val() == "-" && f.textBox.val() > 1)
            f.textBox.val(--f.current);
        else if ($(this).val() == "+" && f.textBox.val() < 21)
            f.textBox.val(++f.current);
        else
            alert("Unvalid number");
    }

    f.more.click(f.showNum);
    f.less.click(f.showNum);
}

$(window).on("load", function(){
    $(".tb").val(1)
});