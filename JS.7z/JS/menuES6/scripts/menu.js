class Menu{
    constructor(sSelector){
        this.menu         = $(sSelector);
        this.menuItems    = this.menu.children("li");

        this.createEvents();
    }

    showSubmenu(event){
        $(event.currentTarget).children(".b-submenu")
        // .show();
        // .addClass("b-submenu_shown");
        // .stop().slideDown();
        .stop().css("display", "block").animate({"opacity" : 1}, 600);
    }

    hideSubMenu(event){
        $(event.currentTarget).children(".b-submenu")
        // .hide();
        // .removeClass("b-submenu_shown");
        // .stop().slideUp();
        .animate({"opacity" : 0}, 600, function(){
            $(this).css("display", "none");
        });
    }

    createEvents(){
        this.menuItems
            .mouseover(this.showSubmenu.bind(this))
            .mouseout(this.hideSubMenu.bind(this));
    }
    
}