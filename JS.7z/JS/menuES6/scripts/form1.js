function Form(sSelector){
    let f = this;
    f.form = $(sSelector);
    f.name = f.form.find(".b-form__name");
    f.surname = f.form.find(".b-form__surname");
    f.season = f.form.find(".b-form__season");
    f.fruit = f.form.find(".b-form__fruit");
    f.animals = f.form.find(".b-form__animals");
    f.review = f.form.find(".b-form__review");
    f.btn = f.form.find(".b-form__ok-button");
    f.langs = f.form.find(".b-langs__lang");

    
    f.showInfo = function(){
        let seasons = "";

        f.season.filter(":checked")
            .each(function(){
                let currentSeason = $(this);
                //console.log(currentSeason.val());
                seasons += currentSeason.val() + " ";
            });
        
        // console.log(
        //     f.name.val()
        //     + "\n"
        //     +  f.surname.val()
        //     + "\n"
        //     + seasons
        //     + "\n"
        //     +  f.fruit.filter(":checked").val()
        //     + "\n"
        //     +  f.animals.val()
        //     + "\n"
        //     +  f.review.val()
        // );
        console.log(
            f.getVal(f.name)
            + "\n"
            +  f.getVal(f.surname)
            + "\n"
            + f.getVal(f.season, ",")
            + "\n"
            +  f.getVal(f.fruit)
            + "\n"
            +  f.getVal(f.animals)
            + "\n"
            +  f.getVal(f.review)
        );
    }
    f.getVal = function(oElem, sSeparator = ""){
        let elemType    = oElem.attr("type")
            elemTagName = oElem.prop("tagName").toLowerCase()
            ;
        if (elemType == "radio"){
            return oElem.filter(":checked").val();
        }
        else if(elemType == "checkbox"){
            let checkboxList = "";

            oElem.filter(":checked")
                .each(function(){
                    let currentCheckBox = $(this);
                    if (checkboxList){
                        checkboxList += sSeparator;
                    }
                    checkboxList += currentCheckBox.val() + " ";
                });
            return checkboxList;
        }
        else if(elemType == "text" || elemTagName == "select" || elemTagName == "textarea"){
            		return oElem.val();
            	}
        else{
            console.log("No element with name:", elemType);
        }
    }

    f.changeLang = function(){
        let currentLang = $(this).data("lang");
        //console.log(currentLang);
        $.each(langs, function(className, langsData){
            //console.log(className, langsData);
            f.form.find("." + className).text(langsData[currentLang]);
            });
    }

    f.btn.click(f.showInfo);
    f.langs.click(f.changeLang);

}
