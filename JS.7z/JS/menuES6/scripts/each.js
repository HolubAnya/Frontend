let goods = {
    "boots" : 3000
    ,"boots1" : 2500
    ,"boots2" : 2800
    ,"boots3" : 1450
};

$.each(goods, function(title, price){
    console.log(title, "-", price);
});

$("label").each(function(){
    console.log($(this).text());
})

$("option").each(function(){
    console.log($(this).val());
})