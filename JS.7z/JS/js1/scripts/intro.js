let subject = "Programming", 
	price 	= 3000,
	length	= ["c++", "Java", "Python", "PHP", "JavaScript"],
	students = {
		"Ivanov": 5,
		"Petrov": 4.6,
		"Sidorov": 4.3
	}
	;
console.log(subject, price);
console.log(length[2]);
length[2] = "C#";
console.log(length[2]);
console.log(students);
console.log(students["Petrov"]);