"use strict";

function swapArr(arr){
    for (let i = 1; i < arr.length; i += 2){
        let t = arr[i];
        arr[i] = arr[i - 1];
        arr[i - 1] = t;
    }
    return arr;
}

function swapArrReduced(arr){
    for (let i = 1; i < arr.length; i += 2)
        arr[i] = [arr[i - 1], arr[i - 1] = arr[i]][0];
    return arr;
} 

let arr1 = [1, 2, 3, 4, 5, 6];

console.log(swapArrReduced(arr1));