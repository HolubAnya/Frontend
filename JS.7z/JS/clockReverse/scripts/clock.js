class Clock{
	constructor(sSelector){
        this.clock = $(sSelector);
        
        this.main();
        setInterval(this.main.bind(this),1000);
    }

	getTimeData(timeSelector, amountOfMs, per = amountOfMs){
        
        let place = this.clock.find("." + timeSelector)
            ,today = new Date()
            ,futureDay = new Date(2019, 2, 8, 12, 30)
            ,time = (futureDay - today)
            ,timeLeft = Math.round((time/amountOfMs)%per);
        place.text(timeLeft < 10 ? "0" + timeLeft : timeLeft);
    }  

    main(){
        this.getTimeData("hours", 3600000);
        this.getTimeData("min", 60000, 60);
        this.getTimeData("sec", 1000, 60);
    }

};