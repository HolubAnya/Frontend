class Gallery{
    constructor(sSelector){

        this.gallery             = $(sSelector);
        this.pictures            = this.gallery.find(".b-picture");
        this.arrowPrev           = this.gallery.find(".b-preview__arrow_prev");
        this.arrowNext           = this.gallery.find(".b-preview__arrow_next");
        this.preview             = this.gallery.find(".b-preview");
        this.previewImage        = this.gallery.find(".b-preview__image");
        this.previewText         = this.gallery.find(".b-preview__text");
        this.currentPictureIndex = 0;
        this.max                 = this.pictures.length;
        this.currentPlace        = this.gallery.find(".b-preview__currentPlace");
        this.maxPlace            = this.gallery.find(".b-preview__maxPlace");
        this.slideshowBtn        = this.gallery.find(".b-preview__slideshowBtn");
        this.isSlideShowStart    = false;
        this.slideshowSetInterval= null;

        this.createEvents();
    }


    

    showPreview(event){
        let jqPicture = $(event.currentTarget);
        this.currentPictureIndex = this.pictures.index(jqPicture);
        this.showImage({}, 0);
        this.preview.addClass("b-preview_shown");
    }
    hidePreview(event){
        if(!event || $(event.target).hasClass("b-preview")){
            this.preview.removeClass("b-preview_shown");
        }
    }
    showPrevious(event){
        this.showImage({}, -1);
    }
    showNext(event){
        this.showImage({}, 1);
    }
    slideshow(){
        if (this.isSlideShowStart){
            window.clearInterval(this.slideshowSetInterval);
            this.isSlideShowStart = false;
            this.slideshowBtn.text("start");
        }
        else{
            this.slideshowSetInterval = window.setInterval(this.showNext.bind(this), 1000);
            this.slideshowBtn.text("stop");
            this.isSlideShowStart = true;
        }
        
    }
    showImage(event, iStep){
        this.currentPictureIndex += iStep;
        console.log(iStep);
        if (this.currentPictureIndex >= this.max){
            this.currentPictureIndex = 0;
        }
        else if (this.currentPictureIndex < 0){
            this.currentPictureIndex = this.max - 1;
        }
        
        let jqPicture  = this.pictures.eq(this.currentPictureIndex).children(".b-picture__image").attr("src").replace("small_", "");
        this.previewImage.attr("src", jqPicture);
        this.currentPlace.text(this.currentPictureIndex + 1);
        this.maxPlace.text(this.max);
        this.previewText.text(this.pictures.eq(this.currentPictureIndex).children(".b-picture__image").attr("alt"));
    }
    escHidePreview(event){
        if(event.which == 27){
            this.hidePreview();
        }  
    }

    createEvents(){
        this.pictures.click(this.showPreview.bind(this));
        this.arrowPrev.click(this.showPrevious.bind(this));
        this.arrowNext.click(this.showNext.bind(this));
        this.preview.click(this.hidePreview.bind(this));
        this.slideshowBtn.click(this.slideshow.bind(this));
        $("body").keyup(this.escHidePreview.bind(this));
    }
}