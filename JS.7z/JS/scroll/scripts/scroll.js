class Scroll{
    constructor(sSelector){
        this.scroll = $(sSelector);
        this.topLink =  this.scroll.find(".topLink");
        this.createEvents();
    }
    showHideTopLink(){
        console.log();
        $(window).scrollTop() > 300 ? this.topLink.show() : this.topLink.hide();
         
    };
    slowScroll(){
        $("html, body").stop().animate({scrollTop:0}, "slow");
    };

    createEvents(){
        $(window).scroll(this.showHideTopLink.bind(this));
        this.topLink.click(this.slowScroll.bind(this));
    };
}