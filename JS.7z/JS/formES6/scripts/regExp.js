class FormChecker{
    constructor(sSelector){
        this.form         = $(sSelector);
        this.textfields   = this.form.find(".b-textfield");
        this.errorMessage = this.form.find(".b-form__message_error");
    }

    

    checkTextfield(event, textfield = {}){
        let currentTextfield  = textfield.length ? textfield : $(event.currentTarget)
        ,currentTextfieldVal  = currentTextfield.val()
        ,regexps              = {
            "name"        : "^[a-zA-Zа-яА-Я \\-]{3,15}$"
            ,"brand"      : "^[A-Za-z_\\-]{1,15}$"
            ,"price"      : "^[0-9]{2,6}$"
            ,"description": "^.+$"
        }
        ,currentTextfieldName = currentTextfield.attr("name")
        ,currentRegExp        = new RegExp(regexps[currentTextfieldName])
        ,istextfieldError        =! currentTextfieldVal.match(currentRegExp)
        ;

        currentTextfield.toggleClass("b-textfield_error", istextfieldError);
        return istextfieldError;
    }

    checkTextfieldsGroup(event){
        event.preventDefault(); //предотвращает событие по умолчанию
        let isFormError = false;
        this.textfields.each(function(){
            console.log(this);
            let currentTextfield = $(this)
            ,isTextfieldError    = this.checkTextfield(currentTextfield);

            if (isTextfieldError){ 
                isFormError = true;
            }
        });
        //isFormError ? this.errorMessage.stop().slideDown() : this.errorMessage.stop().slideUp();
        let methodType = isFormError ? "slideDown" : "slideUp";
        this.errorMessage.stop()[methodType]();
    }

    createEvents(){
        this.textfields.blur(this.checkTextfield.bind(this)); //при потере фокуса (blur) полем - метод проверки одного поля
        this.form.submit(this.checkTextfieldsGroup.bind(this)); //при отправке на сервер - метод проверки всех полей
    }
    
}