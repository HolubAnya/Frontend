class Component{
    constructor(sSelector){
        this.elem = $(sSelector);
    }

    findObject(sSelector){
        return this.elem.find(sSelector);

    }
}