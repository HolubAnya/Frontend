function game(){
    let  m                 = 0
        ,n                 = 2
        ,randIndex         = Math.floor(Math.random() * (n - m + 1)) + m
        ,answers           = ["rock", "scissors", "paper"]
        ,computerAnswer    = answers[randIndex]
        ,userAnswerImg     = document.getElementById("userAnswerImg")
        ,computerAnswerImg = document.getElementById("computerAnswerImg")
        ,userAnswer        = document.getElementById("userAnswer")
        ,messagePlace      = document.getElementById("message")
        ,table             = {
            "rock" : {
                "rock" : 0
                ,"scissors" : 1
                ,"paper" : -1
            }
            ,"scissors" : {
                "rock" : -1
                ,"scissors" : 0
                ,"paper" : 1
            }
            ,"paper" : {
                "rock" : -1
                ,"scissors" : 1
                ,"paper" : 0
            }
        }
        ,message           = {
            "-1" : ":("
            ,"0" : ":/"
            ,"1" : ":)"
        }
        ;
    console.log(userAnswer.value);
    result.style.display   = "block";
    userAnswerImg.src      = "images/" + userAnswer.value + ".png";
    computerAnswerImg.src  = "images/" + computerAnswer + ".png";
    messagePlace.innerText = message[table[userAnswer.value][computerAnswer]];
}


let btn = document.getElementById("btn");
btn.onclick = game;
