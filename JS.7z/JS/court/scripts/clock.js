class Clock{
	constructor(sSelector){
		this.clock = $(sSelector);

		this.hours = this.clock.find(".hours");
		this.point = this.clock.find(".point");
		this.min = this.clock.find(".min");
		this.sec = this.clock.find(".sec");

        this.createEvents();
        this.main();
        setInterval(this.main.bind(this),1000);
    }
	getTimeData(timeSelector, methodType){
        
        let today = new Date()
            ,time = today[methodType]()
            ,place = this.clock.find("." + timeSelector)
            ;
            place.text(time < 10 ? "0" + time : time);
            //console.log(time);
    };

    main(){
        this.getTimeData("hours", "getHours");
        this.getTimeData("min", "getMinutes");
        this.getTimeData("sec", "getSeconds");
    }

	createEvents(){

	};
}