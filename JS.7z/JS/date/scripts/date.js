let today = new Date();
//console.log(today.getDate(), today.getMonth(), today.getFullYear());

let date = today.getHours().toString() + ":" + today.getMinutes() + ":" + today.getSeconds();
//console.log(date);

function game(userAnswer){
    let  m              = 0
        ,n              = 2
        ,randIndex      = Math.floor(Math.random() * (n - m + 1)) + m
        ,answers        = ["rock", "scissors", "paper"]
        ,computerAnswer = answers[randIndex]
        ,table          = {
            "rock" : {
                "rock" : 0
                ,"scissors" : 1
                ,"paper" : -1
            }
            ,"scissors" : {
                "rock" : -1
                ,"scissors" : 0
                ,"paper" : 1
            }
            ,"paper" : {
                "rock" : -1
                ,"scissors" : 1
                ,"paper" : 0
            }
        }
        ,message        = {
            "-1" : ":("
            ,"0" : ":/"
            ,"1" : ":)"
        }
        ;
    console.log(userAnswer);
    console.log(computerAnswer);
    console.log(message[table[userAnswer][computerAnswer]]);
}
game("paper");

function printRange(iNumber){
    if (iNumber){
        console.log(iNumber);
        printRange(--iNumber);  
     }
}
   printRange(4);

