var nums   = [9, -4, 1, 8, -5, 7, -1]
	result = ""
    ;

for ( var i = 0; i < nums.length; i ++){
	//console.log(nums[i]);
	result += nums[i] + " ";
}
console.log(result);
result = "";
for ( var i = 0; i < nums.length; i ++){
	if (nums[i] < 0)
		result += nums[i] + " ";
}
console.log(result);

result = "";
for ( var i = 0; i < nums.length; i ++){
	if (!(nums[i]%2))
		result += nums[i] + " ";
}
console.log(result);

result = "";
for ( var i = 0; i < nums.length; i ++){
	if (nums[i]%2 && nums[i] < 0)
		result += nums[i] + " ";
}
console.log(result);

result = "";
for ( var i = 1; i < nums.length; i += 2){
	result += nums[i] + " ";
}
console.log(result);

result = "";
for ( var j = 1, max = nums[0]; i < nums.length; j ++){
	if (nums[j] > max)
		max = nums[j];
}
console.log(max);