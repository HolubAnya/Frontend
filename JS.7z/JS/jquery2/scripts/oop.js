//class
function Person(height, weight){
    let p = this;
    p.height = height;
    p.weight = weight;
    p.getInfo = function(){
        console.log(p.height, p.weight);
    }

    $(".btn").click(p.getInfo);
}

 let person = new Person(169, 53);
