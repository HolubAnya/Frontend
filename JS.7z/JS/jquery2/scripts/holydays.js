"use strict";
let holidays = {
    1 : {
        1 : ["New Year"]
        ,7 : ["Cristmas"]
        ,20 : ["Boyfriend\`s birthday"]
    }
    ,2 : {}
    ,3 : {}
    ,4 : {}
    ,5 : { 17 : ["Mother\`s birthday"]}
    ,6 : { 12 : ["Father\`s birthday"]}
    ,7 : { 29 : ["Best friend\`s birthday"]}
    ,8 : { 21 : ["Gradpa\`s birthday"]}
    ,9 : { 2 : ["Gradma\`s birthday"]}
    ,10 : {}
    ,11 : {}
    ,12 : {
        29 : ["My birthday"]
        ,17 : ["birthday"]
    }

};

class Holidays{
    constructor(day, month){
        this.day = day;
        this.month = month;
  
        $("#today").click(this.getHoliday.bind(this));
        $("#tomorrow").click(this.getHoliday.bind(this));
    }
    getHoliday(){
        if (holidays[this.month][this.day])
            $("#result").text(holidays[this.month][this.day]);
        else
            $("#result").text("Today there are no holidays");
    }
}
// function Holidays(day, month){

//     let p = this;
//     p.day = day;
//     p.month = month; 
//     p.getHoliday = function(){
//         if (holidays[p.month][p.day])
//             $("#result").text(holidays[p.month][p.day]);
//         else
//             $("#result").text("Today there are no holidays");
//     }
// } 


let today = new Date();
const day = new Holidays(today.getDate(), today.getMonth());
const tomorrow = new Holidays(today.getDate()+1, today.getMonth()+1);



// $("#today").click(day.getHoliday);
// $("#tomorrow").click(tomorrow.getHoliday);

 //person.getInfo();
//  const myarr2 = arr => arr.map(el => el.search(/birthday/gi));


//  function func(arr){
//      let array1 = myarr2(arr);
//      for (let i = 0; i <= arr.length; i++){
//          if (array1[i] != -1){
//              return arr[i];
//          }
//      }
//  }
 
//  function fun(arr){
//      for (let i = 0; i <= arr.length; i++){
//          console.log(func(arr[1]));
//      }
 
//  }
//  fun(arr);
 //console.log(func(arr[0]));