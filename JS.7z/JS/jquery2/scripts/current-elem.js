let blocks = $(".block");
//console.log(blocks[0].className); // js object
//console.log($(blocks[0]).text()); //convert into jquery

blocks.click(showText);

function showText(event){
    console.log($(this)); //$(this) == $(event.currentTarget)
    console.log($(event.currentTarget));
    console.log($(event.currentTarget).text());
}