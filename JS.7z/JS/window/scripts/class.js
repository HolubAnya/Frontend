class Имя_класса{
	constructor(sSelector){
		this.имя_свойства = this. (".");
		
		this.createEvents();
	}
	
	имя_метода(event){
		let элемент_причина_события = $(event.currentTarget);
	}
	
	createEvents(){
		this.имя_свойства(this.имя_метода.bind(this));
	}
}