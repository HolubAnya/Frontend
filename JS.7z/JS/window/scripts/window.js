class Window{
    constructor(sSelector){
        this.win = $(sSelector);
        this.startCountDownBtn = this.win.find(".b-mywindow__start-countdown");
        this.stopCountDownBtn  = this.win.find(".b-mywindow__stop-countdown");
        this.startTickerBtn    = this.win.find(".b-mywindow__start-ticker");
        this.stopTickerBtn     = this.win.find(".b-mywindow__stop-ticker");
        this.openWindowBtn     = this.win.find(".b-mywindow__open-window");
        this.closeWindowBtn    = this.win.find(".b-mywindow__close-window");
        this.tisker            = null;
        this.countdown         = null;
        this.tickerTime        = 0;
        this.tickerPeriod      = 2;
        this.newWindow         = null;

        this.createEvents();

    }

    startCountdown(event){
        let mayIStart = window.confirm("May I start?");
        if (mayIStart){
            this.countdown = window.setTimeout(
                this.countdownNotification, 7000);
        }
        else{
            alert("ok");
        }
    }

    stopCountdown(event){
        window.clearTimeout(this.countdown);
        alert("stop");
    }

    startTicker(event){
        this.ticker = window.setInterval(this.tickerNotification.bind(this), this.tickerPeriod*1000);
    }

    stopTicker(event){
        window.clearInterval(this.ticker);
        console.log("stop timer");
    }

    openWindow(event){
        this.newWindow = window.open("gallery.html", "blank", "width=500, height=500");
    }

    closeWindow(event){
        this.newWindow.close();
    }

    countdownNotification(event){
        alert("Time has come out");
    }

    tickerNotification(event){
        this.tickerTime += this.tickerPeriod;
        console.log(this.tickerTime + " seconds");
    }

    createEvents(){
        this.startCountDownBtn.click(this.startCountdown.bind(this));
        this.stopCountDownBtn.click(this.stopCountdown.bind(this));
        this.startTickerBtn.click(this.startTicker.bind(this));
        this.stopTickerBtn.click(this.stopTicker.bind(this));
        this.openWindowBtn.click(this.openWindow.bind(this));
        this.closeWindowBtn.click(this.closeWindow.bind(this));
    }
}