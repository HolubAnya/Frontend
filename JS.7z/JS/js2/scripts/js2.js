var num = 1
	,num2 = 1
	,result = 0
	,message = "Result: "
	;
console.log(num, num2, result);
result = num++;
console.log(num, num2, result);
result = ++num2;
console.log(num, num2, result);
message += result + ":)"; //дописать в конец
console.log(message);