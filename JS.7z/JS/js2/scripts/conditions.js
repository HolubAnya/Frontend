var orderSum 	 		 = 5000
	,deliverySum 		 = 40
	,discount 	 		 = 0
	,vipClient   		 = true
	,vipClientDiscount   = 3
	,message 			 = ""
	;

if (orderSum >= 500){
	console.log("Free delivery");
	deliverySum = 0;
}
else{
	console.log("Delivery sum is:", deliverySum);
}

if (orderSum >= 700 && orderSum < 2000){
	discount = 3;
}
else if (orderSum >= 2000 && orderSum < 5000){
	discount = 5;
}
else if (orderSum >= 5000){
	discount = 7;
	if (vipClient)
		discount += vipClientDiscount;
	message =  vipClient ? "Editional discount: " + vipClientDiscount + "%" : "to become vipClient buy more";
}
console.log(message);
console.log("Order sum:", orderSum);
orderSum -= orderSum * discount / 100;
console.log("Order sum adn discount:", orderSum);
orderSum += deliverySum;
console.log("Totally:", orderSum);

